/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.bookis.controller;

import java.util.regex.Pattern;

/**
 *
 * @author ajita
 */

public class ValidationUtil {
   private static final Pattern NAME_PATTERN = Pattern.compile("^[a-zA-Z\\s]+$");
   private static final Pattern ISBN_PATTERN = Pattern.compile("^\\d{7}$");
   private static final Pattern GENRE_PATTERN = Pattern.compile("^[a-zA-Z\\s]+$");
 
   /**
     * Validates if a string is null or empty.
     *
     * @param value the string to validate
     * @return true if the string is null or empty, otherwise false
     */

    public static boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }
  
    /**
     * Validates if the name contains only alphabets.
     *
     * @param name the name to validate
     * @return true if valid, otherwise false
     */

    public static boolean isValidName(String name) {
        return !isNullOrEmpty(name) && NAME_PATTERN.matcher(name).matches();
    }

     /**
     * Validates if the ISBN is exactly 7 digits.
     *
     * @param isbn the ISBN to validate
     * @return true if valid, otherwise false
     */

    public static boolean isValidISBN(int isbn) {
        return ISBN_PATTERN.matcher(String.valueOf(isbn)).matches();
    }
   
    /**
    * Validates if the genre contains only alphabets and spaces.
    *
    * @param genre the genre to validate
    * @return true if valid, otherwise false
    */
    public static boolean isValidGenre(String genre) {
        return !isNullOrEmpty(genre) && GENRE_PATTERN.matcher(genre).matches();
    }
    
   /**
    * Validates if the price is a positive integer.
    *
    * @param price the price to validate
    * @return true if valid, otherwise false
    */
    public static boolean isValidPrice(int price) {
        return price > 0;
    }
    
    /**
    * Validates if the published year is a positive integer.
    *
    * @param publishedYear the publishedYear to validate
    * @return true if valid, otherwise false
    */
    public static boolean isValidPublishedYear(int publishedYear) {
        return publishedYear > 0;
    }
     
}

